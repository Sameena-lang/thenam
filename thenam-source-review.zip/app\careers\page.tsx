'use client'

import { useState } from 'react'
import Link from 'next/link'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import CtaBanner from '@/components/CtaBanner'
import {
  Sparkles,
  ArrowRight,
  Briefcase,
  MapPin,
  Clock,
  CheckCircle2,
  Send,
} from 'lucide-react'

export default function CareersPage() {
  const [submitted, setSubmitted] = useState(false)
  const [selectedRole, setSelectedRole] = useState('')

  const jobs = [
    {
      id: 'fullstack-engineer',
      title: 'Full Stack Next.js / TypeScript Engineer',
      department: 'Engineering',
      location: 'Chennai / Remote',
      type: 'Full-time',
      experience: '2 - 5 years',
      desc: 'Architect and ship customer-facing web apps, SaaS dashboards, and performant APIs using Next.js 16, React 19, TypeScript, and PostgreSQL.',
      skills: ['Next.js (App Router)', 'TypeScript', 'Node.js', 'PostgreSQL', 'Tailwind CSS'],
    },
    {
      id: 'ai-ml-engineer',
      title: 'AI & Machine Learning Specialist',
      department: 'AI Labs',
      location: 'Chennai / Hybrid',
      type: 'Full-time',
      experience: '2 - 4 years',
      desc: 'Build custom LLM agents, multi-modal vision models, and RAG pipelines for our enterprise tools and AgriSmart agritech platform.',
      skills: ['Python', 'FastAPI', 'PyTorch / HuggingFace', 'Vector DBs (Pinecone/pgvector)', 'LangChain/LlamaIndex'],
    },
    {
      id: 'ui-ux-designer',
      title: 'Senior Product & UI/UX Designer',
      department: 'Product Design',
      location: 'Remote',
      type: 'Full-time',
      experience: '3 - 6 years',
      desc: 'Craft world-class visual design systems, micro-interactions, responsive mockups, and client design deliverables in Figma.',
      skills: ['Figma', 'Design Systems', 'Micro-animations', 'User Research', 'Prototyping'],
    },
    {
      id: 'frontend-intern',
      title: 'Frontend Developer Intern',
      department: 'Engineering',
      location: 'Chennai / Remote',
      type: 'Internship (3-6 Months)',
      experience: 'Fresher / College Students',
      desc: 'Get hands-on mentorship building modern web portals starting with our ₹1,999* web services and advancing to complex client dashboards.',
      skills: ['HTML5/CSS3', 'JavaScript/TypeScript', 'React Basics', 'Git / GitHub', 'Curiosity to learn'],
    },
  ]

  const handleApply = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setSubmitted(true)
    try {
      const formData = new FormData(e.currentTarget)
      await fetch('/api/applications', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fullName: formData.get('fullName'),
          email: formData.get('email'),
          phone: formData.get('phone'),
          role: selectedRole || formData.get('role'),
          portfolioLink: formData.get('portfolio'),
          message: formData.get('message'),
        }),
      })
    } catch (err) {
      console.error('Application submission error:', err)
    }
    setTimeout(() => setSubmitted(false), 8000)
  }

  return (
    <>
      <Header />

      <main>
        {/* ========================================================
            CAREERS HERO SECTION
            ======================================================== */}
        <section className="inner-page-hero careers-hero-with-bg" aria-label="Careers Header">
          {/* Background image layers */}
          <div className="careers-hero-bg-layer" aria-hidden="true">
            <div className="careers-hero-bg-img" />
            <div className="careers-hero-gradient-overlay" />
            <div className="careers-hero-glow" />
          </div>

          <div className="container" style={{ position: 'relative', zIndex: 5, width: '100%' }}>
            <div className="inner-hero-content">
              <span className="inner-hero-eyebrow">
                <Sparkles size={13} style={{ display: 'inline', marginRight: '6px' }} />
                JOIN THENAM SOFTWARE SOLUTIONS
              </span>
              <h1 className="inner-hero-title">
                Build the future with a team that <span className="accent-cyan">values</span>{' '}
                <span className="accent-lime">craftsmanship.</span>
              </h1>
              <p className="inner-hero-desc">
                We are a group of passionate software engineers, product designers, and AI researchers based in Chennai. We build technology that solves practical problems and scales globally.
              </p>
              <div className="hero-btn-row">
                <a href="#open-roles" className="quote-btn">
                  <span>View Open Positions</span>
                  <ArrowRight size={15} />
                </a>
                <Link href="/about" className="explore-btn">
                  <span>Why Work at Thenam</span>
                  <ArrowRight size={15} />
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* ========================================================
            OPEN ROLES
            ======================================================== */}
        <section className="inner-pale-section" id="open-roles">
          <div className="container">
            <div className="section-head-split" style={{ marginBottom: '45px' }}>
              <div>
                <span className="section-eyebrow">CURRENT VACANCIES</span>
                <h2 className="section-title-large">
                  Explore open <span className="accent-cyan-dark">opportunities.</span>
                </h2>
              </div>
              <p className="section-desc-light" style={{ maxWidth: '420px' }}>
                Don’t see your exact role? Reach out anyway at <strong style={{ color: '#0284c7' }}>careers@thenamsoft.com</strong>.
              </p>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
              {jobs.map((job) => (
                <div
                  key={job.id}
                  style={{
                    background: '#ffffff',
                    border: '1px solid #e2e8f0',
                    borderRadius: '16px',
                    padding: '28px',
                    boxShadow: '0 4px 16px rgba(15, 23, 42, 0.04)',
                    display: 'flex',
                    flexDirection: 'column',
                    justifyContent: 'space-between',
                    gap: '20px',
                    transition: 'border-color 0.2s',
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '14px' }}>
                    <div>
                      <div style={{ display: 'flex', gap: '8px', alignItems: 'center', marginBottom: '8px' }}>
                        <span style={{ fontSize: '11px', fontWeight: '800', background: '#f1f5f9', color: '#475569', padding: '3px 8px', borderRadius: '4px' }}>
                          {job.department}
                        </span>
                        <span style={{ fontSize: '11px', fontWeight: '800', background: '#ecfdf5', color: '#059669', padding: '3px 8px', borderRadius: '4px' }}>
                          {job.type}
                        </span>
                      </div>
                      <h3 style={{ fontSize: '20px', fontWeight: '800', color: '#0f172a', margin: '0 0 6px' }}>{job.title}</h3>
                      <div style={{ display: 'flex', gap: '16px', fontSize: '12px', color: '#64748b' }}>
                        <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}><MapPin size={13} /> {job.location}</span>
                        <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}><Clock size={13} /> {job.experience}</span>
                      </div>
                    </div>

                    <button
                      type="button"
                      className="quote-btn"
                      onClick={() => {
                        setSelectedRole(job.title)
                        document.getElementById('application-form')?.scrollIntoView({ behavior: 'smooth' })
                      }}
                    >
                      <span>Apply Now</span>
                      <ArrowRight size={14} />
                    </button>
                  </div>

                  <p style={{ fontSize: '13.5px', color: '#475569', margin: 0, lineHeight: '1.65' }}>{job.desc}</p>

                  <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', borderTop: '1px solid #f8fafc', paddingTop: '14px' }}>
                    {job.skills.map((skill, idx) => (
                      <span key={idx} className="tag-pill" style={{ background: '#f8fafc' }}>{skill}</span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ========================================================
            QUICK APPLICATION FORM
            ======================================================== */}
        <section className="inner-white-section" id="application-form">
          <div className="container" style={{ maxWidth: '750px' }}>
            <div style={{ textAlign: 'center', marginBottom: '36px' }}>
              <span className="section-eyebrow">DIRECT APPLICATION</span>
              <h2 className="section-title-large">Send your profile to Thenam.</h2>
              <p className="section-desc-light" style={{ margin: '8px auto 0' }}>
                We review every application personally and respond within 48 business hours.
              </p>
            </div>

            {submitted ? (
              <div style={{ background: '#ecfdf5', border: '1px solid #a7f3d0', borderRadius: '12px', padding: '36px', textAlign: 'center' }}>
                <CheckCircle2 size={36} style={{ color: '#10b981', margin: '0 auto 12px' }} />
                <h3 style={{ fontSize: '20px', fontWeight: '800', color: '#065f46', margin: '0 0 6px' }}>Application Received!</h3>
                <p style={{ fontSize: '13.5px', color: '#047857', margin: 0 }}>
                  Thank you for applying. Our talent team will review your portfolio and reach out via email shortly.
                </p>
              </div>
            ) : (
              <form
                onSubmit={handleApply}
                style={{
                  background: '#f8fafc',
                  border: '1px solid #e2e8f0',
                  borderRadius: '16px',
                  padding: '34px',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '18px',
                }}
              >
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(min(100%, 240px), 1fr))', gap: '16px' }}>
                  <label style={{ display: 'flex', flexDirection: 'column', gap: '6px', fontSize: '12px', fontWeight: '700', color: '#334155' }}>
                    Full Name *
                    <input name="fullName" required placeholder="Your full name" style={{ padding: '11px 14px', borderRadius: '8px', border: '1px solid #cbd5e1', background: '#ffffff', fontSize: '13px' }} />
                  </label>

                  <label style={{ display: 'flex', flexDirection: 'column', gap: '6px', fontSize: '12px', fontWeight: '700', color: '#334155' }}>
                    Email Address *
                    <input name="email" required type="email" placeholder="you@example.com" style={{ padding: '11px 14px', borderRadius: '8px', border: '1px solid #cbd5e1', background: '#ffffff', fontSize: '13px' }} />
                  </label>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(min(100%, 240px), 1fr))', gap: '16px' }}>
                  <label style={{ display: 'flex', flexDirection: 'column', gap: '6px', fontSize: '12px', fontWeight: '700', color: '#334155' }}>
                    Phone / WhatsApp *
                    <input name="phone" required placeholder="+91 98765 43210" style={{ padding: '11px 14px', borderRadius: '8px', border: '1px solid #cbd5e1', background: '#ffffff', fontSize: '13px' }} />
                  </label>

                  <label style={{ display: 'flex', flexDirection: 'column', gap: '6px', fontSize: '12px', fontWeight: '700', color: '#334155' }}>
                    Role Applying For *
                    <input name="role" required value={selectedRole} onChange={(e) => setSelectedRole(e.target.value)} placeholder="e.g. Full Stack Engineer" style={{ padding: '11px 14px', borderRadius: '8px', border: '1px solid #cbd5e1', background: '#ffffff', fontSize: '13px' }} />
                  </label>
                </div>

                <label style={{ display: 'flex', flexDirection: 'column', gap: '6px', fontSize: '12px', fontWeight: '700', color: '#334155' }}>
                  LinkedIn / GitHub / Portfolio Link *
                  <input name="portfolio" required placeholder="https://github.com/yourhandle or portfolio" style={{ padding: '11px 14px', borderRadius: '8px', border: '1px solid #cbd5e1', background: '#ffffff', fontSize: '13px' }} />
                </label>

                <label style={{ display: 'flex', flexDirection: 'column', gap: '6px', fontSize: '12px', fontWeight: '700', color: '#334155' }}>
                  Brief Note About Yourself &amp; Projects
                  <textarea name="message" rows={3} placeholder="Tell us about the most interesting thing you have built..." style={{ padding: '11px 14px', borderRadius: '8px', border: '1px solid #cbd5e1', background: '#ffffff', fontSize: '13px', resize: 'vertical' }} />
                </label>

                <button type="submit" className="quote-btn" style={{ justifyContent: 'center', padding: '14px', fontSize: '13.5px' }}>
                  <span>Submit Application</span>
                  <Send size={15} />
                </button>
              </form>
            )}
          </div>
        </section>

        <CtaBanner />
      </main>

      <Footer />
    </>
  )
}
